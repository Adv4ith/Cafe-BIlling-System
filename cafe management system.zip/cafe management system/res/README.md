# Resturant-Management-system-using-python-Tkinter
In the Restaurant management system project in Python, we will be having a GUI using which we will be able to do complete billing for any customer. 
Like we will be able to add items and their price to the bill and also calculate their total price using the total button.
Flowchart
![rms](https://github.com/SanikaKendre/Resturant-Management-system-using-python-Tkinter/assets/84505327/932fa24c-de8f-405b-8a98-4ae5d14c927f)
Home page
![image](https://github.com/SanikaKendre/Resturant-Management-system-using-python-Tkinter/assets/84505327/7f881ab5-4f20-4993-92e4-57c362478d6c)
Admin Sign Up
![image](https://github.com/SanikaKendre/Resturant-Management-system-using-python-Tkinter/assets/84505327/c8b2aa46-4a72-44b9-8bb7-2322f0528b00)
Admin Sign In
![image](https://github.com/SanikaKendre/Resturant-Management-system-using-python-Tkinter/assets/84505327/2daff52c-1b47-4033-9500-bcfd91a6ab50)
Menu Page
![image](https://github.com/SanikaKendre/Resturant-Management-system-using-python-Tkinter/assets/84505327/09435568-463d-4602-b4c9-b6210f4f7af7)
